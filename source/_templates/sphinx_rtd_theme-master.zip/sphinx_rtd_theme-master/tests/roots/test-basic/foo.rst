foo
===

.. toctree::

    bar
